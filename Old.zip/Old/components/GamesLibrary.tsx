import React, { useState } from 'react';
import { Gamepad2, X, Trophy, Clock, Hourglass, PlayCircle, Star, Search, CornerDownRight, Ghost, Users } from 'lucide-react';
import { GAMES_LIBRARY } from '../constants';
import { GameStatus, GameItem } from '../types';

const GamesLibrary: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<GameStatus>('PLAYING');
  const [searchTerm, setSearchTerm] = useState('');

  // Lógica Atualizada:
  // Se houver busca, pesquisa em TODOS os jogos (independente da aba).
  // Se não houver busca, mostra apenas os jogos da aba ativa.
  const filteredGames = searchTerm
    ? GAMES_LIBRARY.filter(game => game.title.toLowerCase().includes(searchTerm.toLowerCase()))
    : GAMES_LIBRARY.filter(game => game.status === activeTab);

  const handleTabChange = (tabId: GameStatus) => {
    setActiveTab(tabId);
    setSearchTerm(''); // Limpa a busca ao trocar de aba para melhor UX
  };

  const handleGameClick = (game: GameItem) => {
    // Se estiver buscando, ao clicar, redireciona para a aba do jogo e sai da busca
    if (searchTerm) {
      setActiveTab(game.status);
      setSearchTerm('');
    }
  };

  const tabs = [
    { id: 'PLAYING', label: 'Jogando Agora', icon: PlayCircle, color: 'text-green-400' },
    { id: 'COMPLETED', label: 'Zerados / Platinas', icon: Trophy, color: 'text-yellow-400' },
    { id: 'MULTIPLAYER', label: 'Jogado c/ Amigos', icon: Users, color: 'text-cyan-400' },
    { id: 'WISHLIST', label: 'Backlog & Futuro', icon: Hourglass, color: 'text-purple-400' },
    { id: 'DROPPED', label: 'Abandonados', icon: Ghost, color: 'text-red-400' },
  ];

  return (
    <>
      {/* --- CARTÃO DE ACESSO (TRIGGER) --- */}
      <div 
        className="group relative w-full bg-dark-card border border-white/10 rounded-2xl p-6 cursor-pointer overflow-hidden transition-all duration-500 hover:border-neon-pink/50 hover:shadow-[0_0_30px_rgba(236,72,153,0.2)]"
        onClick={() => setIsOpen(true)}
      >
        {/* Efeito de fundo animado */}
        <div className="absolute inset-0 bg-gradient-to-br from-neon-pink/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
        <div className="absolute -right-8 -top-8 w-32 h-32 bg-neon-pink/10 rounded-full blur-2xl group-hover:scale-150 transition-transform duration-700"></div>

        <div className="relative z-10 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="p-3.5 bg-gradient-to-br from-gray-800 to-black rounded-xl border border-white/10 shadow-lg group-hover:scale-110 transition-transform duration-300">
               <Gamepad2 className="w-8 h-8 text-neon-pink" />
            </div>
            <div>
              <h3 className="text-xl md:text-2xl font-display font-bold text-white group-hover:text-neon-pink transition-colors">
                Status dos jogos e lista
              </h3>
              <p className="text-gray-400 text-sm font-medium flex items-center gap-2">
                <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span>
                {GAMES_LIBRARY.filter(g => g.status === 'PLAYING').length} Titulos Ativos
              </p>
            </div>
          </div>

          <div className="hidden md:flex items-center gap-2">
             <div className="flex -space-x-3 overflow-hidden pl-2">
                {/* 
                   ==================================================================================
                   🖼️ ONDE TROCAR AS FOTOS DAS BOLINHAS (MINIATURAS)
                   ==================================================================================
                   
                   Para trocar as fotos, basta alterar o link dentro de src="..." nas tags <img> abaixo.
                   
                   COMO FAZER:
                   1. Pegue o link de uma imagem na internet (botão direito na imagem -> copiar endereço da imagem).
                   2. Cole dentro das aspas do src="AQUI".
                   
                   OU (Se a imagem estiver no seu PC):
                   1. Coloque o arquivo de imagem dentro da pasta 'public' do projeto.
                   2. Coloque src="/nome-do-arquivo.jpg"
                */}
                
                {/* 1. Resident Evil 4 */}
                <img 
                  src="RE4.jpg" 
                  alt="Resident Evil 4"
                  title="Resident Evil 4"
                  className="w-10 h-10 rounded-full border-2 border-dark-card object-cover bg-gray-900 hover:scale-110 hover:z-10 transition-transform duration-300"
                />

                {/* 2. Minecraft */}
                <img 
                  src="MINE.png" 
                  alt="Minecraft" 
                  title="Minecraft"
                  className="w-10 h-10 rounded-full border-2 border-dark-card object-cover bg-gray-900 hover:scale-110 hover:z-10 transition-transform duration-300"
                />

                {/* 3. Resident Evil 9 / Requiem (Usando arte dark do Village como placeholder atmosférico) */}
                <img 
                  src="RE9.jpg" 
                  alt="Resident Evil 9 (Requiem)" 
                  title="Resident Evil 9 (Requiem)"
                  className="w-10 h-10 rounded-full border-2 border-dark-card object-cover bg-gray-900 grayscale hover:grayscale-0 hover:scale-110 hover:z-10 transition-all duration-300"
                />
             </div>
             <div className="w-8 h-8 rounded-full bg-dark-bg border border-white/10 flex items-center justify-center text-xs text-gray-400 font-bold ml-2">
               +{Math.max(0, GAMES_LIBRARY.length - 3)}
             </div>
          </div>
        </div>
      </div>

      {/* --- MODAL (POPUP) --- */}
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          {/* Backdrop Blur */}
          <div 
            className="absolute inset-0 bg-black/90 backdrop-blur-md animate-fade-in"
            onClick={() => setIsOpen(false)}
          ></div>

          {/* Janela Principal */}
          <div className="relative w-full max-w-5xl h-[80vh] bg-[#0f111a] border border-white/10 rounded-2xl shadow-2xl flex flex-col md:flex-row overflow-hidden animate-fade-in-up">
            
            {/* Sidebar (Navegação) */}
            <div className="w-full md:w-64 bg-[#0a0c12] border-b md:border-b-0 md:border-r border-white/5 p-6 flex flex-col shrink-0">
              <div className="mb-8 flex items-center gap-3">
                <Gamepad2 className="text-neon-pink w-6 h-6" />
                <span className="font-display font-bold text-white tracking-widest text-lg">LIBRARY</span>
              </div>

              <nav className="flex flex-row md:flex-col gap-2 overflow-x-auto md:overflow-visible pb-2 md:pb-0 scrollbar-hide">
                {tabs.map(tab => {
                  const Icon = tab.icon;
                  // Se estiver buscando, nenhuma aba fica visualmente "ativa" para focar na busca
                  const isActive = !searchTerm && activeTab === tab.id;
                  return (
                    <button
                      key={tab.id}
                      onClick={() => handleTabChange(tab.id as GameStatus)}
                      className={`
                        flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-all duration-300 whitespace-nowrap
                        ${isActive 
                          ? 'bg-white/10 text-white shadow-[0_0_15px_rgba(255,255,255,0.05)] border-l-4 border-neon-pink' 
                          : 'text-gray-500 hover:text-gray-300 hover:bg-white/5 border-l-4 border-transparent'}
                      `}
                    >
                      <Icon className={`w-5 h-5 ${isActive ? tab.color : 'text-gray-600'}`} />
                      {tab.label}
                    </button>
                  );
                })}
              </nav>

              <div className="mt-auto hidden md:block pt-6 border-t border-white/5">
                <div className="relative group">
                    <Search className={`absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 transition-colors ${searchTerm ? 'text-neon-pink' : 'text-gray-600'}`} />
                    <input 
                        type="text" 
                        placeholder="Buscar em tudo..." 
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="w-full bg-[#161b22] border border-white/5 rounded-full py-2 pl-9 pr-4 text-xs text-gray-300 focus:outline-none focus:border-neon-pink/50 focus:bg-[#1c222b] transition-all placeholder:text-gray-600"
                    />
                </div>
              </div>
            </div>

            {/* Conteúdo Principal */}
            <div className="flex-1 flex flex-col relative bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')]">
              
              {/* Header Mobile/Desktop Close */}
              <div className="absolute top-4 right-4 z-20">
                <button 
                  onClick={() => setIsOpen(false)}
                  className="p-2 bg-black/50 hover:bg-red-500/20 text-gray-400 hover:text-red-500 rounded-full transition-colors backdrop-blur-sm"
                >
                  <X size={24} />
                </button>
              </div>

              {/* Título da Seção Atual */}
              <div className="p-8 pb-4">
                <h2 className="text-3xl font-display font-bold text-white flex items-center gap-3">
                  {searchTerm ? (
                    <span className="text-neon-pink flex items-center gap-2">
                       <Search size={28} />
                       Resultados Global
                    </span>
                  ) : (
                    <>
                      {activeTab === 'PLAYING' && <span className="text-green-400">Jogando Atualmente</span>}
                      {activeTab === 'COMPLETED' && <span className="text-yellow-400">Hall da Fama</span>}
                      {activeTab === 'MULTIPLAYER' && <span className="text-cyan-400">Com os Amigos</span>}
                      {activeTab === 'DROPPED' && <span className="text-red-400">Cemitério de Jogos</span>}
                      {activeTab === 'WISHLIST' && <span className="text-purple-400">Lista de Desejos</span>}
                    </>
                  )}
                </h2>
                <p className="text-gray-500 text-sm mt-1 flex items-center gap-2">
                   {searchTerm ? (
                     <>
                        Encontrados <span className="text-white font-bold">{filteredGames.length}</span> jogos.
                        <span className="text-gray-600 text-xs ml-2">(Clique para ir à coleção)</span>
                     </>
                   ) : (
                     <>{filteredGames.length} jogos encontrados nesta coleção</>
                   )}
                </p>
              </div>

              {/* Grid de Jogos */}
              <div className="flex-1 overflow-y-auto p-8 pt-0 custom-scrollbar">
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {filteredGames.map((game, idx) => (
                    <div 
                      key={idx}
                      onClick={() => handleGameClick(game)}
                      className={`
                        group relative h-48 rounded-xl overflow-hidden border border-white/5 bg-[#161b22] 
                        transition-all duration-300 shadow-lg
                        ${searchTerm 
                          ? 'cursor-pointer hover:border-neon-pink/50 hover:-translate-y-1 hover:shadow-neon-pink/10' 
                          : 'hover:border-white/20 hover:-translate-y-1'}
                      `}
                    >
                      {/* Placeholder de Capa (Gradiente) */}
                      <div className={`absolute inset-0 bg-gradient-to-br ${game.coverColor} opacity-20 group-hover:opacity-30 transition-opacity`}></div>
                      
                      {/* Conteúdo do Card */}
                      <div className="absolute inset-0 p-5 flex flex-col justify-between z-10">
                        <div>
                          <span className="text-[10px] font-bold tracking-widest uppercase text-white/40 border border-white/10 px-2 py-0.5 rounded-sm">
                            {game.genre}
                          </span>
                          <h4 className={`mt-2 text-xl font-bold text-white leading-tight transition-colors ${searchTerm ? 'group-hover:text-neon-pink' : 'group-hover:text-neon-blue'}`}>
                            {game.title}
                          </h4>
                        </div>

                        <div className="flex items-center justify-between">
                            {/* Ícone de Status no Card */}
                            {game.status === 'COMPLETED' && (
                                <div className="flex items-center gap-1.5 text-yellow-500 bg-yellow-500/10 px-2 py-1 rounded-md">
                                    <Trophy size={14} />
                                    <span className="text-xs font-bold">{game.rating || "Zerado"}</span>
                                </div>
                            )}
                            {game.status === 'PLAYING' && (
                                <div className="flex items-center gap-1.5 text-green-400 bg-green-500/10 px-2 py-1 rounded-md">
                                    <Clock size={14} />
                                    <span className="text-xs font-bold">Em Progresso</span>
                                </div>
                            )}
                            {game.status === 'WISHLIST' && (
                                <div className="flex items-center gap-1.5 text-purple-400 bg-purple-500/10 px-2 py-1 rounded-md">
                                    <Star size={14} />
                                    <span className="text-xs font-bold">Na Fila</span>
                                </div>
                            )}
                             {game.status === 'MULTIPLAYER' && (
                                <div className="flex items-center gap-1.5 text-cyan-400 bg-cyan-500/10 px-2 py-1 rounded-md">
                                    <Users size={14} />
                                    <span className="text-xs font-bold">Party</span>
                                </div>
                            )}
                             {game.status === 'DROPPED' && (
                                <div className="flex items-center gap-1.5 text-red-400 bg-red-500/10 px-2 py-1 rounded-md">
                                    <Ghost size={14} />
                                    <span className="text-xs font-bold">Abandonado</span>
                                </div>
                            )}

                            {/* Indicador de "Ir para" quando estiver buscando */}
                            {searchTerm && (
                                <div className="opacity-0 group-hover:opacity-100 transition-opacity text-white/50">
                                    <CornerDownRight size={16} />
                                </div>
                            )}
                        </div>
                      </div>

                      {/* Efeito de Scanline decorativo */}
                      <div className="absolute inset-0 bg-[linear-gradient(transparent_50%,rgba(0,0,0,0.5)_50%)] bg-[length:100%_4px] opacity-10 pointer-events-none"></div>
                    </div>
                  ))}
                </div>

                {filteredGames.length === 0 && (
                  <div className="w-full h-40 flex flex-col items-center justify-center text-gray-500 border-2 border-dashed border-white/5 rounded-xl animate-fade-in">
                    <Hourglass className="w-8 h-8 mb-2 opacity-50" />
                    <p>
                        {searchTerm 
                            ? "Nenhum jogo encontrado em nenhuma lista." 
                            : "Nenhum jogo nesta lista."}
                    </p>
                  </div>
                )}
              </div>

            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default GamesLibrary;