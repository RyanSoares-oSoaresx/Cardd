import { LucideIcon } from 'lucide-react';
import React from 'react';

export interface SpecItem {
  component: string;
  model: string;
  icon?: LucideIcon | React.ComponentType<any>;
  tooltip?: string;
  buyUrl?: string; // URL opcional para link de compra (ex: Amazon)
}

export interface SetupCategory {
  title: string;
  items: SpecItem[];
}

export interface StreamerAttribute {
  subject: string;
  A: number;
  fullMark: number;
  description: string;
}

export interface SocialLink {
  name: string;
  url: string;
  icon: LucideIcon | React.ComponentType<any>;
  color: string;
}

// Atualizado com novas categorias
export type GameStatus = 'PLAYING' | 'COMPLETED' | 'WISHLIST' | 'DROPPED' | 'MULTIPLAYER';

export interface GameItem {
  title: string;
  status: GameStatus;
  genre: string;
  coverColor: string; // Classe Tailwind para gradiente ou cor de fundo
  rating?: string; // Ex: "10/10" ou "GOTY"
}