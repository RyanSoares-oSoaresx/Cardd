  import React from 'react';
  import { 
    Cpu, 
    CreditCard, 
    HardDrive, 
    Headphones, 
    Keyboard, 
    Mic, 
    Mouse, 
    Monitor, 
    Gamepad2,
    Youtube,
    Instagram,
    AtSign, // Importando o @ diretamente da Lucide para o Threads
    Camera,
    Laptop,
    Box // Novo ícone para o Gabinete
  } from 'lucide-react';
  import { SetupCategory, StreamerAttribute, SocialLink, GameItem } from './types';

  // Ícones Customizados (SVG via React.createElement para compatibilidade com .ts)
  const DiscordIcon = (props: any) => React.createElement("svg", { ...props, viewBox: "0 0 127.14 96.36", fill: "currentColor" }, 
    React.createElement("path", { d: "M107.7,8.07A105.15,105.15,0,0,0,81.47,0a72.06,72.06,0,0,0-3.36,6.83A97.68,97.68,0,0,0,49,6.83,72.37,72.37,0,0,0,45.64,0,105.89,105.89,0,0,0,19.39,8.09C2.79,32.65-1.71,56.6.54,80.21h0A105.73,105.73,0,0,0,32.71,96.36,77.11,77.11,0,0,0,39.6,85.25a68.42,68.42,0,0,1-10.85-5.18c.91-.66,1.8-1.34,2.66-2a75.57,75.57,0,0,0,64.32,0c.87.71,1.76,1.39,2.66,2a68.68,68.68,0,0,1-10.87,5.19,77,77,0,0,0,6.89,11.1A105.25,105.25,0,0,0,126.6,80.22c2.36-24.44-5.42-48.18-18.9-72.15ZM42.45,65.69C36.18,65.69,31,60,31,53s5-12.74,11.43-12.74S54,46,53.89,53,48.84,65.69,42.45,65.69Zm42.24,0C78.41,65.69,73.25,60,73.25,53s5.06-12.74,11.44-12.74S96.23,46,96.12,53,91.08,65.69,84.69,65.69Z" })
  );

  // Kick Icon - Apenas o "K"
  const KickIcon = (props: any) => React.createElement("svg", { ...props, viewBox: "0 0 24 24", fill: "currentColor" },
      React.createElement("path", { d: "M2,3v18h4.5v-6.5l4.5,6.5h5.5l-6-8l5.5-7h-5l-4.5,5.5v-5.5H2z" })
  );

  const XIcon = (props: any) => React.createElement("svg", { ...props, viewBox: "0 0 24 24", fill: "currentColor" },
    React.createElement("path", { d: "M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" })
  );

  const TwitchIcon = (props: any) => React.createElement("svg", { ...props, viewBox: "0 0 24 24", fill: "currentColor" },
      React.createElement("path", { d: "M11.571 4.714h1.715v5.143H11.57zm4.715 0H18v5.143h-1.714zM6 0L1.714 4.286v15.428h5.143V24l4.286-4.286h2.998L22.286 11.57V0zm14.571 11.143l-3.428 3.428h-3.429l-3 3v-3H6.857V1.714h13.714Z" })
  );

  // Threads Icon - Usando o AtSign da Lucide para ser "apenas um @"
  const ThreadsIcon = AtSign;

  export const BIO_TEXT = "Fala, galera! Sou Ryan, brasileiro de 23 anos, dev, analista de suporte e tecnólogo em Segurança Cibernética. Quando não estou na TI, você me encontra jogando com a rapaziada! Decidi unir o útil ao agradável e comecei a fazer lives para compartilhar gameplay e boas risadas.";

  export const SCHEDULE_TEXT = "Mínimo 3x por semana (Segunda, Quarta e Sexta) às 20h. Sujeito a dias extras!";

  export const ATTRIBUTES_DATA: StreamerAttribute[] = [
    { subject: 'Mecânica', A: 95, fullMark: 100, description: 'Reflexo de Pro Player (ou quase)' },
    { subject: 'Noção de Jogo', A: 85, fullMark: 100, description: 'Leitura de jogo avançada' },
    { subject: 'Carisma', A: 99, fullMark: 100, description: 'Entretenimento garantido' },
    // Sanidade será dinâmica (instável)
    { subject: 'Sanidade', A: 20, fullMark: 100, description: 'Varia drasticamente na Ranked' }, 
    { subject: 'Sorte (RNG)', A: 10, fullMark: 100, description: 'O jogo me odeia' },
    { subject: 'Trab. Equipe', A: 80, fullMark: 100, description: 'Carrego ou afundo o time junto' },
  ];

  export const BATTLE_STATION_DATA: SetupCategory[] = [
    {
      title: "PC JOGOS (DESKTOP)",
      items: [
        { component: "Gabinete", model: "Superframe Onyx Mid Tower", icon: Box },
        { component: "Processador", model: "Intel Core i9-14900K (14ª Ger)", icon: Cpu },
        { component: "Placa de Vídeo", model: "NVIDIA RTX 3060 Ti OC", icon: Monitor },
        { component: "Memória RAM", model: "32GB High-Speed", icon: CreditCard },
        { component: "Armazenamento", model: "1TB NVMe Gen4 + 2TB HDD", icon: HardDrive },
        { component: "Monitor Principal", model: "AOC Agon 24G42HE 200Hz", icon: Monitor },
      ]
    },
    {
      title: "NOTEBOOK STREAM",
      items: [
        { component: "Modelo", model: "Dell Inspiron 7000 Gaming", icon: Laptop },
        { component: "Processador", model: "Intel Core i7-7700HQ", icon: Cpu },
        { component: "Placa de Vídeo", model: "NVIDIA GTX 1050 Ti (4GB)", icon: Monitor },
        { component: "Memória RAM", model: "16GB Dual Channel", icon: CreditCard },
        { component: "Armazenamento", model: "256GB SSD", icon: HardDrive },
      ]
    },
    {
      title: "Periféricos & Gear",
      items: [
        { 
          component: "Headset", 
          model: "Corsair Void Elite Pro Wireless", 
          icon: Headphones,
          buyUrl: "https://www.amazon.com.br/s?k=Corsair+Void+Elite+Pro+Wireless",
          tooltip: "Disponível na Amazon"
        },
        { 
          component: "Mouse Gamer", 
          model: "Corsair Dark Core RGB", 
          icon: Mouse,
          buyUrl: "https://www.amazon.com.br/s?k=Corsair+Dark+Core+RGB",
          tooltip: "Disponível na Amazon"
        },
        { 
          component: "Teclado Mecânico", 
          model: "Corsair K70 MAX RGB", 
          icon: Keyboard,
          buyUrl: "https://www.amazon.com.br/s?k=Corsair+K70+MAX+RGB",
          tooltip: "Disponível na Amazon"
        },
        { 
          component: "Microfone", 
          model: "Fifine AM8 Dinâmico", 
          icon: Mic,
          buyUrl: "https://www.amazon.com.br/s?k=Fifine+AM8",
          tooltip: "Disponível na Amazon"
        },
        { 
          component: "Controle", 
          model: "DualSense Mystic Purple", 
          icon: Gamepad2,
          buyUrl: "https://www.amazon.com.br/s?k=DualSense+Mystic+Purple",
          tooltip: "Disponível na Amazon"
        },
        { 
          component: "Webcam", 
          model: "720p HD", 
          icon: Camera, 
          tooltip: "Marca? Achei no lixo, tá funcionando e eu catei",
          buyUrl: "https://www.google.com/search?tbm=isch&q=macaco+mostrando+dedo+do+meio"
        },
      ]
    }
  ];

  export const SOCIAL_LINKS: SocialLink[] = [
    { name: 'Twitch', url: 'https://www.twitch.tv/otaldosoaresx', icon: TwitchIcon, color: 'hover:text-[#9146FF] hover:border-[#9146FF] hover:shadow-[0_0_20px_rgba(145,70,255,0.6)]' },
    { name: 'YouTube', url: 'https://www.youtube.com/@oSoaresx', icon: Youtube, color: 'hover:text-[#FF0000] hover:border-[#FF0000] hover:shadow-[0_0_20px_rgba(255,0,0,0.6)]' },
    { name: 'Kick', url: 'https://kick.com/osoaresx', icon: KickIcon, color: 'hover:text-[#53FC18] hover:border-[#53FC18] hover:shadow-[0_0_20px_rgba(83,252,24,0.6)]' },
    { name: 'Instagram', url: 'https://www.instagram.com/osoaresx_oficial/', icon: Instagram, color: 'hover:text-[#E1306C] hover:border-[#E1306C] hover:shadow-[0_0_20px_rgba(225,48,108,0.6)]' },
    { name: 'Discord', url: 'https://discord.com/invite/23vEUVMEnB', icon: DiscordIcon, color: 'hover:text-[#5865F2] hover:border-[#5865F2] hover:shadow-[0_0_20px_rgba(88,101,242,0.6)]' },
    { name: 'Twitter (X)', url: 'https://x.com/oSoaresx_', icon: XIcon, color: 'hover:text-white hover:border-white hover:shadow-[0_0_20px_rgba(255,255,255,0.6)]' },
    { name: 'Threads', url: 'https://www.threads.net/@osoaresx_oficial?igshid=NTc4MTIwNjQ2YQ%3D%3D', icon: ThreadsIcon, color: 'hover:text-white hover:border-white hover:shadow-[0_0_20px_rgba(255,255,255,0.6)]' },
  ];

  // ==================================================================================
  // 🎮 TUTORIAL ATUALIZADO: COMO ADICIONAR JOGOS COM CAPA
  // ==================================================================================
  //
  // 1. Copie o "MODELO EM BRANCO" abaixo.
  // 2. Para colocar uma FOTO, preencha o campo 'coverImage'.
  //    - Se for imagem da internet: coverImage: "https://site.com/foto.jpg"
  //    - Se for imagem do PC: Salve na pasta 'public' e use coverImage: "/minha-foto.jpg"
  //
  // 3. Se NÃO quiser foto, apague a linha 'coverImage' e ele usará o 'coverColor'.
  //
  // --- 📋 MODELO EM BRANCO (Copie abaixo) ---
  /*
    {
      title: "Nome do Jogo",
      status: "ESCOLHA_O_STATUS",
      genre: "Gênero",
      coverColor: "from-gray-700 to-black",
      coverImage: "LINK_DA_IMAGEM_AQUI", // (Opcional)
      rating: "Zerado" // (Opcional)
    },
  */
  //
  // --- 🏷️ LEGENDAS DE STATUS ---
  // "PLAYING"     -> Jogando Agora
  // "COMPLETED"   -> Zerados / Platinas
  // "MULTIPLAYER" -> Jogado com Amigos
  // "DROPPED"     -> Abandonados
  // "WISHLIST"    -> Backlog & Futuro
  //
  // ==================================================================================

  export const GAMES_LIBRARY: GameItem[] = [
    
    // --- JOGANDO ATUALMENTE (PLAYING) ---
    { 
      title: "Hytale", 
      status: "PLAYING", 
      genre: "RPG Sandbox", 
      coverColor: "from-green-500 to-cyan-700" 
    },
    { 
      title: "The Evil Within 2", 
      status: "PLAYING", 
      genre: "Survival Horror", 
      coverColor: "from-red-700 to-black" 
    },

    // --- ZERADOS / PLATINAS (COMPLETED) ---
    { 
      title: "Resident Evil 4 Remake", 
      status: "COMPLETED", 
      genre: "Survival Horror", 
      coverColor: "from-yellow-700 to-orange-900", 
      coverImage: "RE4.jpg",
      rating: "Zerado"
    },
    { 
      title: "Resident Evil 7: Biohazard", 
      status: "COMPLETED", 
      genre: "Survival Horror", 
      coverColor: "from-orange-900 to-black",
      rating: "Zerado"
    },
    { 
      title: "Resident Evil Village", 
      status: "COMPLETED", 
      genre: "Survival Horror", 
      coverColor: "from-slate-800 to-black",
      rating: "Zerado"
    },
    { 
      title: "Outlast", 
      status: "COMPLETED", 
      genre: "Psychological Horror", 
      coverColor: "from-green-900 to-black",
      rating: "Zerado"
    },
    { 
      title: "Amnesia: The Dark Descent", 
      status: "COMPLETED", 
      genre: "Survival Horror", 
      coverColor: "from-amber-900 to-black",
      rating: "Zerado"
    },
    { 
      title: "Blair Witch", 
      status: "COMPLETED", 
      genre: "Horror", 
      coverColor: "from-gray-800 to-black",
      rating: "Zerado"
    },
    { 
      title: "Terraria", 
      status: "COMPLETED", 
      genre: "Sandbox Adventure", 
      coverColor: "from-green-600 to-emerald-900",
      rating: "Zerado"
    },
    { 
      title: "Terraria (Calamity Mod)", 
      status: "COMPLETED", 
      genre: "Modded Sandbox", 
      coverColor: "from-red-900 to-purple-900",
      rating: "Zerado"
    },
    { 
      title: "Minecraft", 
      status: "COMPLETED", 
      genre: "Sandbox", 
      coverColor: "from-green-500 to-stone-800",
      coverImage: "MINE.png",
      rating: "Zerado"
    },

    // --- JOGADO COM AMIGOS (MULTIPLAYER) ---
    { 
      title: "Pummel Party", 
      status: "MULTIPLAYER", 
      genre: "Party Game", 
      coverColor: "from-pink-600 to-orange-600" 
    },
    { 
      title: "R.E.P.O.", 
      status: "MULTIPLAYER", 
      genre: "Co-op Shooter", 
      coverColor: "from-red-800 to-gray-900" 
    },
    { 
      title: "Sea of Thieves", 
      status: "MULTIPLAYER", 
      genre: "Pirate Adventure", 
      coverColor: "from-cyan-600 to-blue-900" 
    },
    { 
      title: "Drive Beyond Horizons", 
      status: "MULTIPLAYER", 
      genre: "Driving/Sim", 
      coverColor: "from-orange-500 to-amber-700" 
    },
    { 
      title: "Barony", 
      status: "MULTIPLAYER", 
      genre: "Roguelike RPG", 
      coverColor: "from-purple-800 to-slate-900" 
    },
    { 
      title: "Deducto", 
      status: "MULTIPLAYER", 
      genre: "Social Deduction", 
      coverColor: "from-yellow-600 to-yellow-900" 
    },
    { 
      title: "Deducto 2", 
      status: "MULTIPLAYER", 
      genre: "Social Deduction", 
      coverColor: "from-yellow-500 to-orange-800" 
    },
    { 
      title: "Garry's Mod", 
      status: "MULTIPLAYER", 
      genre: "Sandbox", 
      coverColor: "from-blue-500 to-cyan-700" 
    },
    { 
      title: "The Ranch Simulator", 
      status: "MULTIPLAYER", 
      genre: "Farming/Sim", 
      coverColor: "from-amber-600 to-orange-800" 
    },
    { 
      title: "RV There Yet", 
      status: "MULTIPLAYER", 
      genre: "Co-op Survival", 
      coverColor: "from-green-700 to-emerald-900" 
    },

    // --- LISTA DE DESEJOS / FUTURO (WISHLIST) ---
    { 
      title: "Resident Evil 9 (Requiem)", 
      status: "WISHLIST", 
      genre: "Lança: 27/02", 
      coverColor: "from-gray-800 to-slate-900",
      coverImage: "RE9.jpg" 
    },
    { 
      title: "Silent Hill 2 Remake", 
      status: "WISHLIST", 
      genre: "Terror Psicológico", 
      coverColor: "from-gray-500 to-gray-900" 
    },
    { 
      title: "GTA VI", 
      status: "WISHLIST", 
      genre: "Mundo Aberto", 
      coverColor: "from-purple-500 to-pink-600" 
    },
    { 
      title: "Resident Evil 2 Remake", 
      status: "WISHLIST", 
      genre: "Survival Horror", 
      coverColor: "from-blue-800 to-slate-900" 
    },

    // --- ABANDONADOS / UMA HORA EU VOLTO (DROPPED) ---
    { 
      title: "Dungeon Rampage", 
      status: "DROPPED", 
      genre: "Action RPG", 
      coverColor: "from-red-600 to-orange-800" 
    },
    { 
      title: "GTA V", 
      status: "DROPPED", 
      genre: "Open World", 
      coverColor: "from-green-600 to-emerald-800" 
    },
    { 
      title: "Delta Force", 
      status: "DROPPED", 
      genre: "Tactical FPS", 
      coverColor: "from-stone-600 to-stone-900" 
    },
    { 
      title: "Escape From Tarkov", 
      status: "DROPPED", 
      genre: "Extraction Shooter", 
      coverColor: "from-stone-700 to-green-900" 
    },
    { 
      title: "Don't Starve", 
      status: "DROPPED", 
      genre: "Survival", 
      coverColor: "from-orange-900 to-red-900" 
    },
    { 
      title: "Devour", 
      status: "DROPPED", 
      genre: "Co-op Horror", 
      coverColor: "from-red-900 to-black" 
    },
    { 
      title: "Resident Evil 5", 
      status: "DROPPED", 
      genre: "Action Horror", 
      coverColor: "from-yellow-800 to-orange-900" 
    },
    { 
      title: "Supermarket Together", 
      status: "DROPPED", 
      genre: "Simulator", 
      coverColor: "from-blue-500 to-cyan-600" 
    },
    { 
      title: "The Forest", 
      status: "DROPPED", 
      genre: "Survival Horror", 
      coverColor: "from-green-800 to-black" 
    },
    { 
      title: "Sons of the Forest", 
      status: "DROPPED", 
      genre: "Survival Horror", 
      coverColor: "from-emerald-800 to-black" 
    },
    { 
      title: "Umamusume: Pretty Derby", 
      status: "DROPPED", 
      genre: "Simulation", 
      coverColor: "from-pink-500 to-rose-600" 
    },
    { 
      title: "Genshin Impact", 
      status: "DROPPED", 
      genre: "Action RPG", 
      coverColor: "from-cyan-500 to-blue-600" 
    },
  ];